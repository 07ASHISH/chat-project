var app=angular.module("myapp",["ngRoute","firebase",'ngMaterial','angularMoment','ngAnimate']);

app.config(function($routeProvider,$compileProvider)

{

           // $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|gs|mailto|chrome-extension):/);
            // Angular before v1.2 uses $compileProvider.urlSanitizationWhitelist(...)


    console.log("inconfigue section")

    $routeProvider.when("/",
        {
            "templateUrl":"login-page.html",
            "controller":"loginctrl",
            "resolve":{"obj":function($firebaseArray){

                var refusers = firebase.database().ref().child("users");

                //var  u=$firebaseArray(refusers);
                //u.$loaded().then(function(list){
                //    myservice.users=list;
                //    console.log("loaded");
                //});
                return $firebaseArray(refusers).$loaded();
                },
                "userCurrent":function($firebaseAuth){
                    Auth=$firebaseAuth();




                },
                "obj2":function($firebaseArray){

                    var reffriends = firebase.database().ref().child("friends");

                    //var  u=$firebaseArray(refusers);
                    //u.$loaded().then(function(list){
                    //    myservice.users=list;
                    //    console.log("loaded");
                    //});
                    return $firebaseArray(reffriends).$loaded();
                }
            }
        }).when("/profile",
        {
            "templateUrl":"profile-page.html"
        }).when("/user-page",
        {
            "templateUrl":"user-page.html",
            "controller":"user-pagectrl",
            "resolve":{"obj1":function($firebaseArray)
            {

                        var refchats = firebase.database().ref().child("chats");

                        //var  u=$firebaseArray(refusers);
                        //u.$loaded().then(function(list){
                        //    myservice.users=list;
                        //    console.log("loaded");
                        //});
                        return $firebaseArray(refchats).$loaded();
            },
                "obj2":function($firebaseArray){

                    var reffriends = firebase.database().ref().child("friends");

                    //var  u=$firebaseArray(refusers);
                    //u.$loaded().then(function(list){
                    //    myservice.users=list;
                    //    console.log("loaded");
                    //});
                    return $firebaseArray(reffriends).$loaded();
                },
                "userCurrent":function($firebaseAuth){
                   Auth=$firebaseAuth();
                    return Auth.$requireSignIn();

                }
            }
            //"resolve":function()
            //{
            //
            //}
        })
})


app.run(function($rootScope,$location)
{
    console.log("i am in the run section");
    $rootScope.$on("$routeChangeError", function(event, next, previous, error) {
        // We can catch the error thrown when the $requireSignIn promise is rejected
        // and redirect the user back to the home page
        if (error === "AUTH_REQUIRED") {
            $location.path("/user-page");
        }
        else {

        }
    });



   // var refusers = new Firebase("https://apllication.firebaseio.com/users");


    //myservice.users.$add({"name":"mukul"});
   //console.log(myservice.users);
   // var refchats = firebase.database().ref().child("chats");
   //
   // myservice.chats=$firebaseArray(refchats);
   //
   // console.log(myservice.chats);
   //
   //
   // var reffriends = firebase.database().ref().child("friends");
   //
   // myservice.friends=$firebaseArray(reffriends);
   //
   // console.log(myservice.friends);


})

app.controller("loginctrl",function($scope,obj,obj2,userCurrent,$rootScope,$location,myservice,$firebaseAuth,$firebaseArray)
{


        myservice.users=obj;
    myservice.friends=obj2;
    console.log(obj);
    console.log(obj2);

    $scope.checkuser=function() {

        var auth = $firebaseAuth();
        // login with google
        auth.$signInWithPopup("google").then(function(result) {
            $scope.loaded=false;

            $scope.login=true;
            console.log(result);
            console.log("Logged in as:", result.user.uid);
            console.log(result.user);
            //$rootScope.result=result;
           // myservice.result=result;
            console.log(myservice.users);
            var check = _.findWhere(myservice.users,{"uid":result.user.uid});
            console.log(check);
            if (check)
            {
                console.log("user already exixsts");
               // myservice.connected.$add({"uid":authData.google.id});
                $location.path("/user-page");



                myservice.result=check;
                console.log(check);
            }
            else {

                myservice.users.$add({"name":result.user.displayName,"uid":result.user.uid,"imgURL":result.user.photoURL,"color":"green"}).then(function(r){
                    console.log("added");
                    var check = _.findWhere(myservice.users,{"uid":result.user.uid});
                    console.log(check);
                    myservice.result=check;
                    console.log(myservice.users);
                    myservice.friends.$add({"name":myservice.result.name,"uid":myservice.result.uid});
                    $location.path("/user-page");

                });

                //$scope.url=authData.google.profileImageURL;
                console.log(myservice.users);
                myservice.friends.$add({"name":result.name,"uid":result.uid});
                $location.path("/user-page");
            }

        }).catch(function(error) {
            console.log("Authentication failed:", error);
        });







    }








});



app.controller("user-pagectrl",function($scope,obj1,obj2,$http,userCurrent,$timeout,myservice,$rootScope,$sce,$firebaseArray,$location,$firebaseAuth) {

    myservice.chats = obj1;
    myservice.friends = obj2;
    $scope.users=myservice.users;
    console.log(obj1);
    console.log(obj2);
    console.log(userCurrent);
    $timeout(function(){
        s=document.getElementById("a");
        s.scrollTop= s.scrollHeight;

    },2000)

    if (userCurrent) {
        var refusers = firebase.database().ref().child("users");

        //var  u=$firebaseArray(refusers);
        //u.$loaded().then(function(list){
        //    myservice.users=list;
        //    console.log("loaded");
        //});
       u= $firebaseArray(refusers).$loaded().then(function(list){
           myservice.users=list;
           var check2 = _.findWhere(myservice.users, {"uid": userCurrent.uid});
           myservice.result = check2;
           console.log(check2);
           $scope.imgUser=myservice.result.imgURL;
           $scope.name=myservice.result.name;
           $scope.id=myservice.result.uid;
       });






}


    $scope.imgUser=myservice.result.imgURL;
    $scope.friends=myservice.friends;
    $scope.chats=myservice.chats;

   // $scope.imgUser=$sce.trustAsResourceUrl(myservice.result.user.photoURL);
    $scope.name=myservice.result.name;
    $scope.id=myservice.result.uid;
    $scope.date= new Date();

    //scrollDiv=document.getElementsByClassName('chat-area-div');

    //console.log(scrollDiv);
   // scrollDiv.scrollTop=scrollDiv.scrollHeight-scrollDiv.clientHeight;
   // $scope.initialize=function(i){
   //     $scope.last=i;
   //     console.log(i);
   //     document.getElementById('anchor'+i).scrollIntoView();
   // }


    $scope.showprofile=function()
    {
        $scope.statusforchat=true;
        $scope.statusforprofile=false;
    }
    $scope.selectfriend=function(f)
    {
       $scope.key={"fromUid": f.uid};
        $scope.keyCurrent={"fromUid":myservice.result.uid};
    }
    $scope.pickColor=function(c){
        $scope.bg={
            "background":c
        };

    }
//$scope.scroll=function(l,i)
//{
//
//    if(true)
//    {
//        console.log("hey");
//        var scroller=document.getElementsByClassName('chat-area-div')[0];
//        console.log(scroller.scrollTop,scroller.scrollHeight);
//        scroller.scrollTop=scroller.scrollHeight;
//
//    }
//

//}
    var userRef = firebase.database().ref("connect" + "/" + myservice.result.uid)
           //var testRef = firebase.database().ref("connect")
    var connectedRef = firebase.database().ref(".info/connected");
    $timeout(function()
    {
        connectedRef.on("value", function(snap) {
            if (snap.val() === true) {
                userRef.set(true)
                userRef.onDisconnect().set(firebase.database.ServerValue.TIMESTAMP)
            } else {
                userRef.set(firebase.database.ServerValue.TIMESTAMP);
            }
        });
    },0)
    var q = firebase.database().ref("connect");
    var w=$firebaseArray(q).$loaded(function(res){
        console.log(res);
        for(var i=0;i<myservice.users.length;i++)
                    {
                        var found = _.findWhere(myservice.users,{uid : res[i].$id})
                        if(res[i].$value == true)
                            {
                                found['color'] = "green";
                            }
                       else
                           found['color'] = "red";
                   console.log(myservice.users);
                   myservice.users.$save(found);
                //$scope.users = data.users;
               }

    })
    //console.log(arr);

    $scope.sendchat=function(){
        $scope.status=true;
        var d=new Date();
        d=d.toString();
        var scroller=document.getElementsByClassName('chat-area-div')[0];
        console.log(scroller.scrollTop,scroller.scrollHeight);
        scroller.scrollTop=scroller.scrollHeight;
        var words=$scope.chattext.split(" ");
        console.log(words[0]);
        if(words[0]=="@bot")
        {


            $http.get("http://api.program-o.com/v2/chatbot").then(function(data){
                console.log(data);
                var refbot = firebase.database().ref().child("bot");

                //var  u=$firebaseArray(refusers);
                //u.$loaded().then(function(list){
                //    myservice.users=list;
                //    console.log("loaded");
                //});
                $firebaseArray(refbot).$loaded().then(function(d){
                    myservice.bot=d;
                    myservice.bot.$add({"msg":data.data.Abstract});

                })
                ;


            });

        }


        myservice.chats.$add({"name":myservice.result.name,"fromUid":myservice.result.uid,"imgUrl":myservice.result.imgURL,"toUid":"all","msg":$scope.chattext,"atch":false,"date":d});


    }
    $scope.myFunct = function(keyEvent) {
        if (keyEvent.which === 13) {



        $scope.status = true;
        var d = new Date();
        d = d.toString();


        myservice.chats.$add({
            "name": myservice.result.name,
            "fromUid": myservice.result.uid,
            "imgUrl": myservice.result.imgURL,
            "toUid": "all",
            "msg": $scope.chattext,
            "atch": false,
            "date": d
        }).then(function(){
            var scroller = document.getElementsByClassName('chat-area-div')[0];
            console.log(scroller.scrollTop, scroller.scrollHeight);
            scroller.scrollTop = scroller.scrollHeight;


        });
            //var scroller = document.getElementsByClassName('chat-area-div')[0];
            //console.log(scroller.scrollTop, scroller.scrollHeight);
            //scroller.scrollTop = scroller.scrollHeight;


        }
    }
    $scope.signingout=function()
    {
       var Auth= $firebaseAuth();
        var userRef = firebase.database().ref().child('presence' + myservice.result.uid);
        userRef.remove();
        Auth.$signOut();
            // Sign-out successful.
            $location.path("/");


            console.log("signed out");

    }
    $scope.downloadPic=function(c){
       $location.path(c.atch);



    }


    var inputElement = document.getElementById("input");
    inputElement.addEventListener("change", handleFiles, false);
    //function handleFiles() {
    //    var fileList = this.files; /* now you can work with the file list */
    //}

    var inputElement2=document.getElementById("input2");
    inputElement2.addEventListener("change",handelFiles2,false);
    function handelFiles2(){
        var storageRef = firebase.storage().ref();
        var file =this.files[0];
        console.log(file);
        console.log(file.type);
        var metadata = {
            contentType: file.type
        };

// Upload the file to the path 'images/rivers.jpg'
// We can use the 'name' property on the File API to get our file name
        var uploadTask = storageRef.child('images/' + file.name).put(file,metadata);

// Register three observers:
// 1. 'state_changed' observer, called any time the state changes
// 2. Error observer, called on failure
// 3. Completion observer, called on successful completion
        uploadTask.on('state_changed', function(snapshot){
            // Observe state change events such as progress, pause, and resume
            // See below for more detail
            console.log(snapshot.metadata);
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            console.log('Upload is ' + progress + '% done');
            switch (snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or 'paused'
                    console.log('Upload is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // or 'running'
                    console.log('Upload is running');
                    break;
            }
        }, function(error) {
            // Handle unsuccessful uploads
        }, function() {
            console.log("cheking");
            var storageRef = firebase.storage().ref();
            console.log(storageRef);
            storageRef.child('images/' + file.name).getDownloadURL().then(function(url) {
                // Get the download URL for 'images/stars.jpg'
                // This can be inserted into an <img> tag
                // This can also be downloaded directly
                //var storageRef = firebase.storage().ref();
                //storageRef.child('images/' + file.name).getMetadata().then(function(metadata) {
                //    // Metadata now contains the metadata for 'images/forest.jpg'
                //}).catch(function(error) {
                //    // Uh-oh, an error occurred!
                //});
                console.log("in download success");
                console.log(url,file.type);
                var d= new Date();
                myservice.chats.$add({"name":myservice.result.name,"fromUid":myservice.result.uid,"imgUrl":myservice.result.imgURL,"toUid":"all","msg":"","atch":url,"type":file.type,"filename":file.name,"date":d});


            }).catch(function(error) {
                // Handle any errors
            });



        });

    };

    function handleFiles() {
        /* now you can work with the file list */
        var storageRef = firebase.storage().ref();
        console.log(storageRef);
// Points to 'images'



        var file =this.files[0];

// Upload the file to the path 'images/rivers.jpg'
// We can use the 'name' property on the File API to get our file name
        var uploadTask = storageRef.child('images/' + file.name).put(file);

// Register three observers:
// 1. 'state_changed' observer, called any time the state changes
// 2. Error observer, called on failure
// 3. Completion observer, called on successful completion
        uploadTask.on('state_changed', function(snapshot){
            // Observe state change events such as progress, pause, and resume
            // See below for more detail
            var progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            console.log('Upload is ' + progress + '% done');
            switch (snapshot.state) {
                case firebase.storage.TaskState.PAUSED: // or 'paused'
                    console.log('Upload is paused');
                    break;
                case firebase.storage.TaskState.RUNNING: // or 'running'
                    console.log('Upload is running');
                    break;
            }
        }, function(error) {
            // Handle unsuccessful uploads
        }, function() {
            console.log("cheking");
            var storageRef = firebase.storage().ref();
            console.log(storageRef);
            storageRef.child('images/' + file.name).getDownloadURL().then(function(url) {
                // Get the download URL for 'images/stars.jpg'
                // This can be inserted into an <img> tag
                // This can also be downloaded directly
                console.log("in download success");
                $scope.imgUser=url;
                console.log(url);
                for(var i=0;i<myservice.users.length;i++){

                    if(myservice.users[i].uid==myservice.result.uid)
                    {
                        console.log(myservice.users[i]);
                        console.log($scope.imgUser);
                        myservice.users[i].imgURL=$scope.imgUser;
                        myservice.users.$save(myservice.users[i]).then(function(){
                            console.log("success");
                        });
                        console.log(myservice.users[i]);
                    }

                }

            }).catch(function(error) {
                // Handle any errors
            });



        });

    };










});



app.service("myservice",function($firebaseArray)
{
    this.users=[];
    this.chats=[];
    this.emojies=[];
    this.friends=[];
    this.result={};
    this.connected=[];
    this.bot=[];
});





